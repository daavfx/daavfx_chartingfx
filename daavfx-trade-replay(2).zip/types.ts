export interface OHLCData {
    time: number;
    open: number;
    high: number;
    low: number;
    close: number;
}

export interface VolumeData {
    time: number;
    value: number;
    color: string;
}

export interface VaultItem {
    id: number;
    title: string;
    category: 'drawing' | 'replay' | 'idea' | 'lesson';
    asset: string;
    timeframe: string;
    tags: string[];
    notes: string;
    createdAt: string;
    thumbnail: null | string;
    drawingsCount: number;
    color: string;
}

export type ToolType = 
    | 'crosshair' | 'pointer' | 'trendline' | 'hline' | 'vline' 
    | 'ray' | 'extended' | 'fibretracement' | 'fibextension' 
    | 'pitchfork' | 'rectangle' | 'circle' | 'triangle' 
    | 'channel' | 'xabcd' | 'headshoulders' | 'elliott' 
    | 'text' | 'note' | 'callout' | 'arrow' | 'pricelabel' 
    | 'pricerange' | 'daterange' | 'longposition' | 'shortposition' 
    | 'magnet' | 'lock' | 'visibility' | 'delete';

export interface TradeEntry {
    id: string;
    pair: string;
    type: 'LONG' | 'SHORT';
    time: string;
    entry: number;
    exit: number;
    lots: number;
    pnl: number;
    r: number;
    status: 'WIN' | 'LOSS' | 'BE';
    setup: string;
}

export interface JournalDay {
    date: string;
    trades: TradeEntry[];
    note: string;
    mood: 'disciplined' | 'neutral' | 'tilted' | 'fearful' | 'greedy';
}

export type ChartType = 'Candle' | 'Bar' | 'Line' | 'Area';

export interface SessionStats {
    balance: number;
    startBalance: number;
    winRate: number;
    tradesCount: number;
    wins: number;
    losses: number;
    pnl: number;
}